# finalkatalonweb

This is the repository for the Platinum Challenge Quality Assurance Bootcamp Binar Academy

Team: Dhiki Purwanto, Tommy Abdullah, Saiful Hadi, Sofia Awiliyah, Afi Sherma, Tri Yuniarti Ambarsari, Sandri Alfarisi.
