<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Feature Add Item Daftar Jual Page</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>d276178a-84b6-480d-8d5d-ffd4bdd3a4e9</testSuiteGuid>
   <testCaseLink>
      <guid>b4059d5a-c7bb-4bdb-b53e-35d097b8b5b4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/StepDefinition/Feature Add Item/ADDITEMDAFTARJUAL001 - User Want To Add Item</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a003c278-2f0d-44fa-ad00-c99830350574</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/StepDefinition/Feature Add Item/ADDITEMDAFTARJUAL002 - User Click Back in Tambah Produk Page</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1341596a-5650-4fc9-8d6c-3e044dd81eb1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/StepDefinition/Feature Add Item/ADDITEMDAFTARJUAL003 - User Click Back After Filling All Field</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>39cfb3d5-2c9e-412b-87dc-05cdc8f5cb05</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/StepDefinition/Feature Add Item/ADDITEMDAFTARJUAL004 - Search Produk in Tambah Produk Page</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
