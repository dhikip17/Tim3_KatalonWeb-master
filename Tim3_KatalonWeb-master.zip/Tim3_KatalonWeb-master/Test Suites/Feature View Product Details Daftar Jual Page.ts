<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Feature View Product Details Daftar Jual Page</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>abbe396e-bf17-4add-8bef-ec42d170bf90</testSuiteGuid>
   <testCaseLink>
      <guid>53a117ad-65ba-4cba-8f25-7ad8d6742a6a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/StepDefinition/Feature View Product Detail/PRODUCTDAFTARJUAL001 - View Product Details in Daftar Jual Page</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
